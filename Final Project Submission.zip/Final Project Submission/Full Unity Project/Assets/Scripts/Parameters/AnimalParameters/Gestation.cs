﻿using System;

public enum Gestation
{
    QUICK, MEDIUM, LONG
}