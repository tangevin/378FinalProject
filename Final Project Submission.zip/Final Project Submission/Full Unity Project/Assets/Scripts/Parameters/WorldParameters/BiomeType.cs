﻿using System;

public enum BiomeType
{
    DESERT = 0,
    FOREST = 1,
    MOUNTAIN = 2,
    OCEAN = 3,
    PLAIN = 4,
    RIVER = 5
}