﻿using System;

public enum SpaceNeeded
{
    SMALL, MEDIUM, LARGE, EXTRALARGE
}