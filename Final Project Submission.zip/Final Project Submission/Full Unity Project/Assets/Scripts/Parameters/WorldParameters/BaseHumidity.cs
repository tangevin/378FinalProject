﻿using System;

public enum BaseHumidity
{
    LOW, MEDIUM, HIGH
}