﻿using System;

public enum Poisonous
{
    NONE = 3,
    MINOR = 1,
    MAJOR = -1,
    DEADLY = -2
}