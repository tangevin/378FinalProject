﻿using System;

public enum Babies
{
    SOLO=1, TWINS=2, QUAD=4, OCTUPLE=8
}