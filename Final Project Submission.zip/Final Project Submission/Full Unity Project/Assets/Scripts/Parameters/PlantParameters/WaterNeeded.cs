﻿using System;

public enum WaterNeeded
{
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3
}