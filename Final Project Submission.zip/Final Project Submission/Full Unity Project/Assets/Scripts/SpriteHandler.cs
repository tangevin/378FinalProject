﻿using UnityEngine;
using System.Collections;

public class SpriteHandler : MonoBehaviour
{
    public Sprite animalSprite;
    public Sprite plantSprite;
    public Sprite halfSprite;
    public Sprite[] biomeSprites;


	// Use this for initialization
	void Start () {
	
	}
}
