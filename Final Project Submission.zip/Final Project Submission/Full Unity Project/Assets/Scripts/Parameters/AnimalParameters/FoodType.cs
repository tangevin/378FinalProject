﻿using System;

public enum FoodType
{
    CARNIVORE = 0,
    OMNIVORE = 1,
    HERBIVORE = 2
}

