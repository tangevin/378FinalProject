﻿using System;

public enum TemperatureTolerance
{
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3
}