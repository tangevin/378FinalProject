﻿using System;

public enum Aggression
{
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3
}