﻿using System;

public enum FoodNeeded
{
    LOW = 1,
    MEDIUM = 5,
    HIGH = 10
}