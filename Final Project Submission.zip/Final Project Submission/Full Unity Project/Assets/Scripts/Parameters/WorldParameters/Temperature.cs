﻿using System;

public enum Temperature
{
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3
}