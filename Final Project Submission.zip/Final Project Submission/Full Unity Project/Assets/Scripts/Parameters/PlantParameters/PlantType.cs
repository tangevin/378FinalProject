﻿using System;

public enum PlantType
{
    TREE, BUSH, GRASS
}