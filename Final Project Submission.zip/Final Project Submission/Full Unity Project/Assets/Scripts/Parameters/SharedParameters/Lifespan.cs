﻿using System;

public enum Lifespan
{
    SHORT=50,
    MEDIUM =100,
    LONG =200
}

