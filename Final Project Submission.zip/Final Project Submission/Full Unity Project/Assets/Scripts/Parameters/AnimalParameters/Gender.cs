﻿using System;

public enum Gender
{
    MALE, FEMALE
}