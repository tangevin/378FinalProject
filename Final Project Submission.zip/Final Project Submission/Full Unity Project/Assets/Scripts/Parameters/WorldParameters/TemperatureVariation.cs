﻿using System;

public enum TemperatureVariation
{
    LOW, MEDIUM, HIGH
}