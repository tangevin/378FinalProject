﻿using System;

public enum Speed
{
    SLOW = 1,
    MEDIUM = 2,
    FAST = 3,
    SONIC = 4
}