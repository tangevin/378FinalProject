﻿using System;

public enum HumidityVariation
{
    LOW, MEDIUM, HIGH
}