﻿using System;

public enum Perception
{
    SHORT, MEDIUM, FAR
}