﻿using System;

public enum BodyType
{
    BIPED, QUADPED
}