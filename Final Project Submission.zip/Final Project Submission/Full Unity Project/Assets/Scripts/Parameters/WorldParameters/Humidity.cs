﻿using System;

public enum Humidity
{
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3
}