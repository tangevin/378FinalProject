﻿using System;

public enum AnimalSize
{
    TINY = 1,
    SMALL = 2,
    MEDIUM = 4,
    LARGE = 6,
    HUGE = 10
}