﻿using System;

public enum BaseTemperature
{
    LOW, MEDIUM, HIGH
}