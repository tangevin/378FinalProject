I am Become God
by Travis Angevine, Sam Lakes, Nate Diamond, and Alex Lazar

For windows, the game can be found in the windows build folder. Double click the executable to run the game.
For mac, the game can be found in the mac build folder. Double click the app to run the game.

Instructions and controls can be learned in game, or here:

Players can place plants and animals into the game world and
watch as they interact.

The first dropdown menu on the left side of the screen determines
which type of entity you want to place. The remaining dropdown
menus determine the parameters for the entity that you want to place.

In order to place an entity into the world, select a value for
each of the different parameter types, and give your new species
a name. Once you have done that, right click on a tile in the game
in order to place it. How your new entity does depends on its
interaction with the environment.



Controls:
Left Click on a tile to view information about the selected tile
Right Click to place entity. Must have a value selected for all
	parameters to be able to place.
Click and drag to pan around the world.
Mouse wheel to zoom